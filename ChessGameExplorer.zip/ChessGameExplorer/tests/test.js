const C = require('../app/src/main/assets/chess.js');
let fails = 0;
const ok = (c, m) => { if (!c) { fails++; console.log('FAIL', m); } };
const P = [
 ['start', C.START, [20, 400, 8902, 197281]],
 ['kiwipete', 'r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1', [48, 2039, 97862]],
 ['pos3 (ep/pins)', '8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1', [14, 191, 2812, 43238, 674624]],
 ['pos4 (promo/castle)', 'r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1', [6, 264, 9467, 422333]],
 ['pos5', 'rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8', [44, 1486, 62379]],
 ['pos6', 'r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10', [46, 2079, 89890]],
];
for (const [n, f, exp] of P) {
  exp.forEach((e, i) => { const got = C.perft(C.fromFEN(f), i + 1); ok(got === e, `perft ${n} d${i + 1}: ${got} != ${e}`); });
  console.log('perft ok-run:', n);
}
// FEN round trip
ok(C.toFEN(C.fromFEN(C.START)) === C.START, 'fen roundtrip');
// scenario checks
let s = C.fromFEN('7k/5Q2/6K1/8/8/8/8/8 b - - 0 1'); ok(C.status(s).code === 'stalemate', 'stalemate');
s = C.fromFEN('6k1/5ppp/8/8/8/8/8/R5K1 w - - 0 1'); const L0 = C.legal(s); const mv = L0.find(m => C.sqName(m.to) === 'a8');
ok(C.san(s, mv, L0) === 'Ra8#', 'mate san'); C.make(s, mv); ok(C.status(s).code === 'checkmate' && C.status(s).winner === 'w', 'checkmate winner');
s = C.fromFEN('8/8/8/8/8/5k2/8/4K1B1 w - - 0 1'); ok(C.status(s).code === 'insufficient', 'K+B v K');
s = C.fromFEN('8/8/8/8/8/5k2/8/4K1BN w - - 0 1'); ok(!C.status(s).over, 'K+B+N not dead');
s = C.fromFEN('4k3/p7/8/8/8/8/8/4K3 w - - 100 80'); ok(C.status(s).code === 'fifty', '50 move');
s = C.fromFEN('rnbqkbnr/ppp1p1pp/8/3pPp2/8/8/PPPP1PPP/RNBQKBNR w KQkq f6 0 3'); ok(C.legal(s).some(m => m.ep), 'en passant offered');
s = C.fromFEN('r3k2r/8/8/8/8/8/8/R3K2R w KQkq - 0 1'); ok(C.legal(s).filter(m => m.castle).length === 2, 'both castles');
s = C.fromFEN('r3k2r/8/8/8/8/5r2/8/R3K2R w KQkq - 0 1'); ok(C.legal(s).filter(m => m.castle).length === 1 || C.legal(s).filter(m => m.castle).length === 0, 'cannot castle through check'); ok(!C.legal(s).some(m => m.castle === 1), 'no O-O through f-file attack');
s = C.fromFEN('8/P7/8/8/8/8/k6K/8 w - - 0 1'); ok(C.legal(s).filter(m => m.promo).length === 4, '4 promotions');
// generated games: replay independently and validate
const tally = {}; let plies = 0, maxp = 0, t0 = Date.now();
const N = 1500;
for (let id = 1; id <= N; id++) {
  const g = C.generate(id), g2 = C.generate(id);
  ok(g.pgn === g2.pgn, 'deterministic ' + id);
  let st = C.fromFEN(C.START);
  g.sans.forEach((x, i) => {
    const L = C.legal(st), m = L.find(mm => C.san(st, mm, L) === x);
    if (!m) { ok(false, `game ${id} ply ${i}: illegal san ${x}`); return; }
    C.make(st, m);
    ok(g.boards[i + 1] === st.b.map(c => c || '.').join(''), `board mismatch ${id}/${i + 1}`);
    ok(g.moves[i].from === m.from && g.moves[i].to === m.to, 'move squares');
  });
  const fin = C.status(st), L = C.legal(st);
  const r = g.result;
  if (r.kind === 'checkmate') ok(fin.code === 'checkmate' && fin.winner === (r.code === '1-0' ? 'w' : 'b') && g.sans.at(-1).endsWith('#'), `mate mismatch ${id}`);
  else if (r.kind === 'stalemate') ok(fin.code === 'stalemate', `stalemate mismatch ${id}`);
  else if (r.kind === 'insufficient') ok(fin.code === 'insufficient', `insuff mismatch ${id}`);
  else if (r.kind === 'fifty') ok(fin.code === 'fifty', `fifty mismatch ${id}`);
  else if (r.kind === 'progress') ok(!fin.over && g.plies === C.MAX_PLIES, `progress mismatch ${id}`);
  ok(g.finalFEN === C.toFEN(st), 'final fen');
  tally[r.kind] = (tally[r.kind] || 0) + 1; plies += g.plies; maxp = Math.max(maxp, g.plies);
  if (id === 183729) console.log('Game 183729:', g.result.title, g.result.sub, g.plies, 'plies');
}
console.log('results over', N, 'games:', tally, 'avg plies', (plies / N).toFixed(1), 'max', maxp, (Date.now() - t0) + 'ms');
const a = C.generate(183729), b = C.generate(183730); ok(a.pgn !== b.pgn, 'neighbouring ids differ');
const big = C.generate(9007199254740991); ok(big.plies > 0, 'max safe id works');
console.log(a.pgn.split('\n\n')[1].slice(0, 160) + '...');
console.log(fails ? fails + ' FAILURES' : 'ALL TESTS PASSED');
process.exit(fails ? 1 : 0);
