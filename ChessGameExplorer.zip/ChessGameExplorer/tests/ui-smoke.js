const fs=require('fs'),vm=require('vm');
const els={};
function mk(id){const e={id,children:[],dataset:{},style:{setProperty(){}},textContent:'',value:'',disabled:false,className:'',scrollTop:0,scrollWidth:10,clientWidth:100,clientHeight:60,offsetHeight:60,offsetTop:0,
 classList:{_s:new Set(),add(c){this._s.add(c)},remove(c){this._s.delete(c)},toggle(c,f){f?this._s.add(c):this._s.delete(c)},contains(c){return this._s.has(c)}},
 appendChild(c){this.children.push(c);return c},querySelector(sel){const m=sel.match(/data-ply="(\d+)"/);return m?this.children.find(c=>c.dataset&&c.dataset.ply===m[1])||null:null},
 blur(){},closest(){return null},remove(){}};return e;}
const doc={getElementById:id=>els[id]||(els[id]=mk(id)),createElement:()=>mk('x'),querySelectorAll:()=>[],addEventListener(){},body:{classList:{toggle(){},add(){},remove(){}},appendChild(){}}};
const ctx={document:doc,window:null,console,Chess:require('../app/src/main/assets/chess.js'),getComputedStyle:()=>({paddingLeft:'8',paddingRight:'8',paddingTop:'8',paddingBottom:'8',borderTopWidth:'5'}),
 localStorage:{_d:{},getItem(k){return this._d[k]||null},setItem(k,v){this._d[k]=v}},setTimeout,clearTimeout,Number};
ctx.window=ctx;ctx.innerWidth=390;ctx.innerHeight=844;ctx.addEventListener=()=>{};
ctx.window.AndroidBridge={copy(t){ctx.copied=t}};
vm.createContext(ctx);
for(const id of ['app','game','nav','boardbox','board','list'])doc.getElementById(id);
els.app.clientWidth=390;els.app.clientHeight=844;
vm.runInContext(fs.readFileSync('app/src/main/assets/app.js','utf8'),ctx);
const st=()=>ctx.__cge.state(), t=id=>els[id].textContent;
let bad=0;const ok=(c,m)=>{if(!c){bad++;console.log('FAIL',m)}else console.log('ok  ',m)};
ok(t('gid')==='Game: 1'&&st().ply===0,'starts at Game 1, move 0');
els.fwd.onclick();els.fwd.onclick();els.fwd.onclick();
ok(st().ply===3&&String(t('mvnum'))==='3','move arrow advances, counter updates');
els.next.onclick();ok(st().id===2&&st().ply===0&&t('gid')==='Game: 2','Next opens game 2, move reset');
els.fwd.onclick();els.back.onclick();ok(st().id===1&&st().ply===0&&els.back.disabled,'Back returns to game 1 (then disabled)');
els.fwd.onclick();els.fwd.onclick();els.next.onclick();els.back.onclick();ok(st().id===1&&st().ply===0,'game and move navigation independent');
els.end.onclick();ok(st().ply===st().plies&&els.fwd.disabled,'End jumps to last move');
els.restart.onclick();ok(st().ply===0&&els.prev.disabled,'Restart returns to move 0');
els.mvIn.value='19';els.mvGo.onclick();ok(st().ply===19,'jump to move 19');
els.idIn.value='42';els.idGo.onclick();ok(st().id===42,'search game 42');
els.pgn.onclick();ok(/\[Event "Chess Game Explorer"\]/.test(ctx.copied||'')&&/1\. /.test(ctx.copied),'PGN copied via bridge');
els.rand.onclick();ok(st().id>=1&&st().id<=999999,'random game');
els.newg.onclick();ok(st().id>=1e9,'new generated game');
els.idIn.value='0';els.idGo.onclick();ok(st().id>=1e9,'invalid id 0 rejected');
console.log(bad?bad+' FAILED':'UI SMOKE TEST PASSED');process.exit(bad?1:0);
