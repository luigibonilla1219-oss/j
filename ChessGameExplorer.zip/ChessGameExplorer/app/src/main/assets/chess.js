/* Chess engine + deterministic game generator. No dependencies. */
(function (root) {
'use strict';
const FILES = 'abcdefgh';
const START = 'rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1';
const MAX_PLIES = 400;
const isW = c => c >= 'A' && c <= 'Z';
const sqName = s => FILES[s & 7] + (8 - (s >> 3));
const KN = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
const KG = [[-1,-1],[-1,0],[-1,1],[0,-1],[0,1],[1,-1],[1,0],[1,1]];
const DIAG = [[-1,-1],[-1,1],[1,-1],[1,1]];
const ORTH = [[-1,0],[1,0],[0,-1],[0,1]];
// castling bits: 1=K 2=Q 4=k 8=q ; squares: a8=0 ... h1=63
const CMASK = new Array(64).fill(0);
CMASK[60] = 3; CMASK[63] = 1; CMASK[56] = 2; CMASK[4] = 12; CMASK[7] = 4; CMASK[0] = 8;
const VAL = { p: 1, n: 3, b: 3, r: 5, q: 9, k: 0 };

function fromFEN(fen) {
  const [pl, tn, ca, ep, hm, fm] = fen.trim().split(/\s+/);
  const b = [];
  for (const ch of pl) {
    if (ch === '/') continue;
    if (ch >= '1' && ch <= '8') for (let i = 0; i < +ch; i++) b.push('');
    else b.push(ch);
  }
  const s = { b, turn: tn, castle: 0, ep: -1, half: +hm || 0, full: +fm || 1, k: { w: -1, b: -1 } };
  if (ca.includes('K')) s.castle |= 1; if (ca.includes('Q')) s.castle |= 2;
  if (ca.includes('k')) s.castle |= 4; if (ca.includes('q')) s.castle |= 8;
  if (ep !== '-') s.ep = (8 - +ep[1]) * 8 + FILES.indexOf(ep[0]);
  b.forEach((c, i) => { if (c === 'K') s.k.w = i; if (c === 'k') s.k.b = i; });
  return s;
}
function toFEN(s) {
  let out = '';
  for (let r = 0; r < 8; r++) {
    let e = 0;
    for (let c = 0; c < 8; c++) { const ch = s.b[r * 8 + c]; if (!ch) e++; else { if (e) out += e; e = 0; out += ch; } }
    if (e) out += e; if (r < 7) out += '/';
  }
  const ca = (s.castle & 1 ? 'K' : '') + (s.castle & 2 ? 'Q' : '') + (s.castle & 4 ? 'k' : '') + (s.castle & 8 ? 'q' : '') || '-';
  return `${out} ${s.turn} ${ca} ${s.ep < 0 ? '-' : sqName(s.ep)} ${s.half} ${s.full}`;
}

function attacked(s, sq, by) {
  const b = s.b, r = sq >> 3, c = sq & 7, w = by === 'w';
  const pr = w ? r + 1 : r - 1;
  if (pr >= 0 && pr < 8) {
    const p = w ? 'P' : 'p';
    if (c > 0 && b[pr * 8 + c - 1] === p) return true;
    if (c < 7 && b[pr * 8 + c + 1] === p) return true;
  }
  const n = w ? 'N' : 'n', k = w ? 'K' : 'k';
  for (const [dr, dc] of KN) { const rr = r + dr, cc = c + dc; if (rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] === n) return true; }
  for (const [dr, dc] of KG) { const rr = r + dr, cc = c + dc; if (rr >= 0 && rr < 8 && cc >= 0 && cc < 8 && b[rr * 8 + cc] === k) return true; }
  const B = w ? 'B' : 'b', R = w ? 'R' : 'r', Q = w ? 'Q' : 'q';
  for (const [dr, dc] of DIAG) {
    let rr = r + dr, cc = c + dc;
    while (rr >= 0 && rr < 8 && cc >= 0 && cc < 8) { const x = b[rr * 8 + cc]; if (x) { if (x === B || x === Q) return true; break; } rr += dr; cc += dc; }
  }
  for (const [dr, dc] of ORTH) {
    let rr = r + dr, cc = c + dc;
    while (rr >= 0 && rr < 8 && cc >= 0 && cc < 8) { const x = b[rr * 8 + cc]; if (x) { if (x === R || x === Q) return true; break; } rr += dr; cc += dc; }
  }
  return false;
}

function gen(s) {
  const b = s.b, w = s.turn === 'w', out = [], opp = w ? 'b' : 'w';
  const enemy = ch => ch !== '' && isW(ch) !== w;
  for (let sq = 0; sq < 64; sq++) {
    const p = b[sq];
    if (p === '' || isW(p) !== w) continue;
    const r = sq >> 3, c = sq & 7, t = p.toLowerCase();
    if (t === 'p') {
      const dir = w ? -1 : 1, start = w ? 6 : 1, last = w ? 0 : 7, r1 = r + dir;
      if (r1 < 0 || r1 > 7) continue;
      const push = (to, cap, ep) => {
        if ((to >> 3) === last) for (const pr of 'qrbn') out.push({ from: sq, to, p, cap, promo: pr, ep: false, castle: 0 });
        else out.push({ from: sq, to, p, cap, promo: '', ep: !!ep, castle: 0 });
      };
      if (b[r1 * 8 + c] === '') {
        push(r1 * 8 + c, '');
        if (r === start && b[(r + 2 * dir) * 8 + c] === '') push((r + 2 * dir) * 8 + c, '');
      }
      for (const dc of [-1, 1]) {
        const cc = c + dc; if (cc < 0 || cc > 7) continue;
        const to = r1 * 8 + cc;
        if (enemy(b[to])) push(to, b[to]);
        else if (to === s.ep && b[to] === '') push(to, w ? 'p' : 'P', true);
      }
    } else if (t === 'n' || t === 'k') {
      for (const [dr, dc] of (t === 'n' ? KN : KG)) {
        const rr = r + dr, cc = c + dc; if (rr < 0 || rr > 7 || cc < 0 || cc > 7) continue;
        const to = rr * 8 + cc, x = b[to];
        if (x === '' || enemy(x)) out.push({ from: sq, to, p, cap: x, promo: '', ep: false, castle: 0 });
      }
      if (t === 'k' && sq === (w ? 60 : 4)) {
        const base = w ? 56 : 0, kb = w ? 1 : 4, qb = w ? 2 : 8, rook = w ? 'R' : 'r';
        if ((s.castle & kb) && b[base + 5] === '' && b[base + 6] === '' && b[base + 7] === rook &&
            !attacked(s, base + 4, opp) && !attacked(s, base + 5, opp) && !attacked(s, base + 6, opp))
          out.push({ from: sq, to: base + 6, p, cap: '', promo: '', ep: false, castle: 1 });
        if ((s.castle & qb) && b[base + 1] === '' && b[base + 2] === '' && b[base + 3] === '' && b[base] === rook &&
            !attacked(s, base + 4, opp) && !attacked(s, base + 3, opp) && !attacked(s, base + 2, opp))
          out.push({ from: sq, to: base + 2, p, cap: '', promo: '', ep: false, castle: 2 });
      }
    } else {
      const dirs = t === 'b' ? DIAG : t === 'r' ? ORTH : DIAG.concat(ORTH);
      for (const [dr, dc] of dirs) {
        let rr = r + dr, cc = c + dc;
        while (rr >= 0 && rr < 8 && cc >= 0 && cc < 8) {
          const to = rr * 8 + cc, x = b[to];
          if (x === '') out.push({ from: sq, to, p, cap: '', promo: '', ep: false, castle: 0 });
          else { if (enemy(x)) out.push({ from: sq, to, p, cap: x, promo: '', ep: false, castle: 0 }); break; }
          rr += dr; cc += dc;
        }
      }
    }
  }
  return out;
}

function make(s, m) {
  const b = s.b, w = s.turn === 'w', dir = w ? -1 : 1;
  const u = { cap: '', capSq: m.to, castle: s.castle, ep: s.ep, half: s.half, full: s.full, kw: s.k.w, kb: s.k.b };
  b[m.from] = '';
  if (m.ep) { const cs = m.to - dir * 8; u.cap = b[cs]; u.capSq = cs; b[cs] = ''; }
  else u.cap = b[m.to];
  b[m.to] = m.promo ? (w ? m.promo.toUpperCase() : m.promo) : m.p;
  if (m.castle === 1) { b[m.to - 1] = b[m.to + 1]; b[m.to + 1] = ''; }
  else if (m.castle === 2) { b[m.to + 1] = b[m.to - 2]; b[m.to - 2] = ''; }
  if (m.p === 'K') s.k.w = m.to; else if (m.p === 'k') s.k.b = m.to;
  s.castle &= ~CMASK[m.from] & ~CMASK[m.to];
  const pawn = m.p === 'P' || m.p === 'p';
  s.ep = pawn && Math.abs(m.to - m.from) === 16 ? (m.from + m.to) / 2 : -1;
  s.half = (pawn || u.cap !== '') ? 0 : s.half + 1;
  if (!w) s.full++;
  s.turn = w ? 'b' : 'w';
  return u;
}
function unmake(s, m, u) {
  const b = s.b;
  s.turn = s.turn === 'w' ? 'b' : 'w';
  b[m.to] = '';
  if (m.castle === 1) { b[m.to + 1] = b[m.to - 1]; b[m.to - 1] = ''; }
  else if (m.castle === 2) { b[m.to - 2] = b[m.to + 1]; b[m.to + 1] = ''; }
  b[m.from] = m.p;
  if (u.cap !== '') b[u.capSq] = u.cap;
  s.castle = u.castle; s.ep = u.ep; s.half = u.half; s.full = u.full; s.k.w = u.kw; s.k.b = u.kb;
}

function inCheck(s) {
  return s.turn === 'w' ? attacked(s, s.k.w, 'b') : attacked(s, s.k.b, 'w');
}
function legal(s) {
  const mv = gen(s), out = [], w = s.turn === 'w', opp = w ? 'b' : 'w';
  for (const m of mv) {
    const u = make(s, m);
    if (!attacked(s, w ? s.k.w : s.k.b, opp)) out.push(m);
    unmake(s, m, u);
  }
  return out;
}

function san(s, m, L) {
  let t;
  if (m.castle) t = m.castle === 1 ? 'O-O' : 'O-O-O';
  else {
    const pt = m.p.toLowerCase(), cap = m.cap !== '';
    if (pt === 'p') t = (cap ? FILES[m.from & 7] + 'x' : '') + sqName(m.to) + (m.promo ? '=' + m.promo.toUpperCase() : '');
    else {
      t = pt.toUpperCase();
      const others = L.filter(o => o !== m && o.p === m.p && o.to === m.to);
      if (others.length) {
        const sf = others.some(o => (o.from & 7) === (m.from & 7));
        const sr = others.some(o => (o.from >> 3) === (m.from >> 3));
        if (!sf) t += FILES[m.from & 7]; else if (!sr) t += (8 - (m.from >> 3)); else t += sqName(m.from);
      }
      if (cap) t += 'x';
      t += sqName(m.to);
    }
  }
  const u = make(s, m);
  if (inCheck(s)) t += legal(s).length ? '+' : '#';
  unmake(s, m, u);
  return t;
}

function insufficient(s) {
  const minors = [];
  for (let i = 0; i < 64; i++) {
    const c = s.b[i]; if (c === '' || c === 'K' || c === 'k') continue;
    const t = c.toLowerCase();
    if (t === 'p' || t === 'r' || t === 'q') return false;
    minors.push({ t, sq: i });
  }
  if (minors.length <= 1) return true;
  if (minors.every(m => m.t === 'b')) {
    const col = m => ((m.sq >> 3) + (m.sq & 7)) & 1;
    return minors.every(m => col(m) === col(minors[0]));
  }
  return false;
}

function status(s, L) {
  L = L || legal(s);
  if (!L.length) return inCheck(s) ? { over: true, code: 'checkmate', winner: s.turn === 'w' ? 'b' : 'w' } : { over: true, code: 'stalemate', winner: null };
  if (insufficient(s)) return { over: true, code: 'insufficient', winner: null };
  if (s.half >= 100) return { over: true, code: 'fifty', winner: null };
  return { over: false };
}

function resultInfo(code, winner) {
  switch (code) {
    case 'checkmate': return { code: winner === 'w' ? '1-0' : '0-1', title: 'Checkmate', sub: (winner === 'w' ? 'White' : 'Black') + ' Wins', kind: code };
    case 'stalemate': return { code: '1/2-1/2', title: 'Stalemate', sub: 'Draw', kind: code };
    case 'insufficient': return { code: '1/2-1/2', title: 'Draw', sub: 'Insufficient material', kind: code };
    case 'fifty': return { code: '1/2-1/2', title: 'Draw', sub: '50-move rule', kind: code };
    case 'repetition': return { code: '1/2-1/2', title: 'Draw', sub: 'Threefold repetition', kind: code };
    default: return { code: '*', title: 'Game In Progress', sub: '', kind: 'progress' };
  }
}

function key(s, L) {
  return s.b.map(c => c || '.').join('') + s.turn + s.castle + (L.some(m => m.ep) ? s.ep : '-');
}
const boardStr = s => s.b.map(c => c || '.').join('');

function hash(id) {
  const lo = id >>> 0, hi = Math.floor(id / 4294967296) >>> 0;
  let h = Math.imul(lo ^ 0x9e3779b9, 0x85ebca6b) ^ Math.imul(hi + 0x7f4a7c15, 0xc2b2ae35);
  h ^= h >>> 15; h = Math.imul(h, 0x2c1b3c6d); h ^= h >>> 12; h = Math.imul(h, 0x297a2d39); h ^= h >>> 15;
  return h >>> 0;
}
function mulberry32(a) {
  return function () {
    a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pgnText(g) {
  const hd = [['Event', 'Chess Game Explorer'], ['Site', 'Game ' + g.id], ['Date', '????.??.??'], ['Round', '-'],
    ['White', 'Generated White'], ['Black', 'Generated Black'], ['Result', g.result.code], ['GameID', String(g.id)]];
  let mt = '';
  g.sans.forEach((x, i) => { mt += (i % 2 === 0 ? (i / 2 + 1) + '. ' : '') + x + ' '; });
  return hd.map(([k, v]) => `[${k} "${v}"]`).join('\n') + '\n\n' + mt + g.result.code;
}

/* Every positive integer id deterministically maps to exactly one legal game. */
function generate(id) {
  const rnd = mulberry32(hash(id));
  const s = fromFEN(START);
  const sans = [], moves = [], boards = [boardStr(s)], checks = [-1], seen = new Map();
  let end = null;
  for (;;) {
    const L = legal(s);
    const k = key(s, L), n = (seen.get(k) || 0) + 1; seen.set(k, n);
    const st = status(s, L);
    if (st.over) { end = st; break; }
    if (n >= 3) { end = { code: 'repetition', winner: null }; break; }
    if (sans.length >= MAX_PLIES) { end = { code: 'progress', winner: null }; break; }
    // choose: mate-in-one if available, else weighted (captures / checks / queening favoured)
    let chosen = null, total = 0; const ws = [];
    for (const m of L) {
      let wgt = 1;
      if (m.cap) wgt += 3 + VAL[m.cap.toLowerCase()];
      if (m.promo === 'q') wgt += 8;
      const u = make(s, m);
      if (inCheck(s)) { wgt += 2; if (legal(s).length === 0) chosen = chosen || m; }
      unmake(s, m, u);
      ws.push(wgt); total += wgt;
    }
    if (!chosen) {
      let r = rnd() * total, i = 0;
      while (i < L.length - 1 && r >= ws[i]) { r -= ws[i]; i++; }
      chosen = L[i];
    }
    sans.push(san(s, chosen, L));
    moves.push({ from: chosen.from, to: chosen.to });
    make(s, chosen);
    boards.push(boardStr(s));
    checks.push(inCheck(s) ? (s.turn === 'w' ? s.k.w : s.k.b) : -1);
  }
  const g = { id, sans, moves, boards, checks, startFEN: START, finalFEN: toFEN(s), plies: sans.length, result: resultInfo(end.code, end.winner) };
  g.pgn = pgnText(g);
  return g;
}

function perft(s, d) {
  if (d === 0) return 1;
  const L = legal(s); if (d === 1) return L.length;
  let n = 0;
  for (const m of L) { const u = make(s, m); n += perft(s, d - 1); unmake(s, m, u); }
  return n;
}

const API = { START, fromFEN, toFEN, legal, inCheck, make, unmake, san, status, insufficient, generate, perft, sqName, resultInfo, MAX_PLIES };
if (typeof module !== 'undefined' && module.exports) module.exports = API; else root.Chess = API;
})(typeof self !== 'undefined' ? self : this);
