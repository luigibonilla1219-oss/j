(function () {
'use strict';
const $ = id => document.getElementById(id);
const GL = { K: '\u265A', Q: '\u265B', R: '\u265C', B: '\u265D', N: '\u265E', P: '\u265F' };
let id = 1, ply = 0, game = null;
const cache = new Map();

function getGame(n) {
  if (!cache.has(n)) { cache.set(n, Chess.generate(n)); if (cache.size > 30) cache.delete(cache.keys().next().value); }
  return cache.get(n);
}
const boardEl = $('board'), sq = [];
for (let i = 0; i < 64; i++) {
  const d = document.createElement('div');
  d.className = 'sq ' + ((((i >> 3) + (i & 7)) % 2) ? 'dk' : 'lt');
  boardEl.appendChild(d); sq.push(d);
}
function fit(el, max, min) {
  let s = max; el.style.fontSize = s + 'px';
  while (s > min && el.scrollWidth > el.clientWidth + 0.5) { s -= 1; el.style.fontSize = s + 'px'; }
}
function toast(t) { const e = $('toast'); e.textContent = t; e.classList.add('on'); clearTimeout(toast.t); toast.t = setTimeout(() => e.classList.remove('on'), 1600); }
function save() { try { localStorage.setItem('cge_id', String(id)); } catch (e) {} }

function buildList() {
  const L = $('list'); L.textContent = '';
  game.sans.forEach((s, i) => {
    if (i % 2 === 0) { const n = document.createElement('span'); n.className = 'num'; n.textContent = (i / 2 + 1) + '.'; L.appendChild(n); }
    const b = document.createElement('button'); b.className = 'mv'; b.dataset.ply = i + 1; b.textContent = s; L.appendChild(b);
  });
}
function render() {
  const g = game, bs = g.boards[ply], last = ply > 0 ? g.moves[ply - 1] : null, chk = g.checks[ply];
  for (let i = 0; i < 64; i++) {
    const ch = bs[i], el = sq[i];
    el.textContent = ch === '.' ? '' : GL[ch.toUpperCase()] + '\uFE0E';
    el.dataset.p = ch === '.' ? '' : (ch === ch.toUpperCase() ? 'w' : 'b');
    el.classList.toggle('last', !!last && (i === last.from || i === last.to));
    el.classList.toggle('chk', i === chk);
  }
  $('gid').textContent = 'Game: ' + id;
  $('res1').textContent = g.result.title; $('res2').textContent = g.result.sub;
  $('mvnum').textContent = ply; $('mvtot').textContent = '/ ' + g.plies;
  $('prev').disabled = ply === 0; $('fwd').disabled = ply === g.plies;
  $('back').disabled = id <= 1; $('next').disabled = id >= Number.MAX_SAFE_INTEGER;
  document.querySelectorAll('.mv.cur').forEach(e => e.classList.remove('cur'));
  const cur = ply > 0 ? $('list').querySelector('.mv[data-ply="' + ply + '"]') : null;
  if (cur) { cur.classList.add('cur'); const L = $('list'); if (cur.offsetTop < L.scrollTop || cur.offsetTop > L.scrollTop + L.clientHeight - 30) L.scrollTop = cur.offsetTop - L.clientHeight / 2; }
  else if (ply === 0) $('list').scrollTop = 0;
  fitAll();
}
function fitAll() {
  const top = $('game').clientHeight;
  fit($('gid'), Math.max(18, top * 0.62), 12);
  const rh = $('result').clientHeight;
  const two = !!game.result.sub;
  fit($('res1'), Math.max(14, rh * (two ? 0.34 : 0.4)), 10);
  fit($('res2'), Math.max(12, rh * 0.3), 9);
}
function setId(n, p) {
  if (!Number.isSafeInteger(n) || n < 1) { toast('Enter a Game ID of 1 or more'); return; }
  id = n; game = getGame(n); ply = p || 0; buildList(); save(); render();
}
function setPly(p) { ply = Math.max(0, Math.min(game.plies, p)); render(); }

function layout() {
  const app = $('app'), W = window.innerWidth, H = window.innerHeight, land = W > H * 1.05;
  document.body.classList.toggle('land', land);
  const cs = getComputedStyle(app);
  const px = k => parseFloat(cs[k]) || 0;
  const innerW = app.clientWidth - px('paddingLeft') - px('paddingRight');
  const innerH = app.clientHeight - px('paddingTop') - px('paddingBottom');
  const gap = 8, top = $('game').offsetHeight || 60, btn = $('nav').offsetHeight || 60;
  let bs;
  if (land) bs = Math.min(innerH - top - gap, innerW * 0.56);
  else bs = Math.min(innerW, innerH - top - 2 * btn - 4 * gap - 90);
  bs = Math.max(120, Math.floor(bs));
  app.style.setProperty('--bs', bs + 'px');
  const bb = $('boardbox'); bb.style.width = bs + 'px'; bb.style.height = bs + 'px';
  const bw = parseFloat(getComputedStyle(bb).borderTopWidth) || 5;
  boardEl.style.fontSize = ((bs - 2 * bw) / 8 * 0.82) + 'px';
  if (game) fitAll();
}
function copyText(t) {
  try { if (window.AndroidBridge && AndroidBridge.copy) { AndroidBridge.copy(t); return true; } } catch (e) {}
  try { if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(t); return true; } } catch (e) {}
  try { const ta = document.createElement('textarea'); ta.value = t; ta.style.cssText = 'position:fixed;opacity:0'; document.body.appendChild(ta); ta.select(); const ok = document.execCommand('copy'); ta.remove(); return ok; } catch (e) { return false; }
}
const num = v => { const t = String(v).replace(/[^0-9]/g, ''); return t ? Number(t) : NaN; };

$('next').onclick = () => setId(id + 1);
$('back').onclick = () => { if (id > 1) setId(id - 1); };
$('prev').onclick = () => setPly(ply - 1);
$('fwd').onclick = () => setPly(ply + 1);
$('restart').onclick = () => setPly(0);
$('end').onclick = () => setPly(game.plies);
$('rand').onclick = () => setId(1 + Math.floor(Math.random() * 999999));
$('newg').onclick = () => { setId(1000000000 + Math.floor(Math.random() * 999000000000)); toast('New game generated'); };
$('pgn').onclick = () => toast(copyText(game.pgn) ? 'PGN copied' : 'Copy failed');
const goId = () => { const n = num($('idIn').value); if (isNaN(n)) { toast('Type a Game ID'); return; } setId(n); $('idIn').value = ''; $('idIn').blur(); };
const goMv = () => { const n = num($('mvIn').value); if (isNaN(n)) { toast('Type a move number'); return; } setPly(n); $('mvIn').value = ''; $('mvIn').blur(); };
$('idGo').onclick = goId; $('mvGo').onclick = goMv;
$('idIn').onkeydown = e => { if (e.key === 'Enter') goId(); };
$('mvIn').onkeydown = e => { if (e.key === 'Enter') goMv(); };
$('list').onclick = e => { const b = e.target.closest('.mv'); if (b) setPly(Number(b.dataset.ply)); };
document.addEventListener('keydown', e => {
  if (e.target && e.target.tagName === 'INPUT') return;
  if (e.key === 'ArrowLeft') setPly(ply - 1); else if (e.key === 'ArrowRight') setPly(ply + 1);
});
window.addEventListener('resize', layout);
window.addEventListener('orientationchange', () => setTimeout(layout, 100));

const start = 1; // always open on Game 1
layout(); setId(start); layout();
window.__cge = { setId, setPly, state: () => ({ id, ply, plies: game.plies }) };
})();
