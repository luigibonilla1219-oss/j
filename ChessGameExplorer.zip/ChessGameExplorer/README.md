# Chess Game Explorer (Android)

Black-and-white chess game browser. Every positive Game ID maps to exactly one legal chess game,
generated deterministically by the built-in engine, so Game 183729 is the same on every device.

## Build the APK
Option A - Android Studio (easiest)
1. Install Android Studio (Koala or newer). File > Open > select this folder. Accept the Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). Output: app/build/outputs/apk/debug/app-debug.apk

Option B - command line (needs JDK 17, Android SDK platform 34, Gradle 8.7)
    cp local.properties.example local.properties   # edit sdk.dir
    gradle assembleDebug

## Install
- Phone: enable USB debugging, plug in, then: adb install -r app/build/outputs/apk/debug/app-debug.apk
- Or copy the APK to the phone, open it, and allow "install unknown apps".

## Layout of the code
- app/src/main/assets/chess.js  engine (legal moves, castling, en passant, promotion, check/mate/stalemate, draws, SAN, PGN, game generator)
- app/src/main/assets/app.js, index.html, style.css  the UI
- app/src/main/java/.../MainActivity.kt  WebView host + clipboard bridge (no third-party libraries)

## Tests (need only Node.js)
    node tests/test.js        # perft vs. published counts, rule scenarios, 1,500 generated games replayed and verified
    node tests/ui-smoke.js    # button and navigation logic

## Notes
- Games end by checkmate, stalemate, insufficient material, 50-move rule or threefold repetition (treated as a draw).
  A game still running after 400 half-moves would show "Game In Progress".
- Buttons: Next/Back change Game ID; arrows change move; Random (IDs under 1,000,000); New (random 10-12 digit ID);
  Restart/End; PGN copies to clipboard; Game ID and Move # boxes jump directly; tap any move in the list.

## No Android Studio? Build in the cloud
Upload this folder to a new GitHub repository (include the hidden .github folder). Open the Actions tab,
run "Build APK", then download "ChessGameExplorer-apk" from the finished run and unzip it to get app-debug.apk.
